error id: iGkNKNOvQcmeTCc/JrWt0A==
### Bloop error:

Read data from io exception: java.net.SocketException: Socket closed
#### Short summary: 

Read data from io exception: java.net.SocketException: Socket closed